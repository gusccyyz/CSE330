#ifndef STACK_H
#define STACK_H
#include <iostream>
#include <list>
#include <string>

using namespace std;

class stack {
    
public:
   stack();
   /**
      Pushes a value onto the stack.
   */
   void push(string s);

   /**
      Yields the top value on the stack.
   */
   string top() const;

   /**
      Removes a value from the stack.
   */
   void pop();

   /**
      Finds the size of the stack.
   */
   int size() const;
    
    // determine if the stack is empty
    bool empty() const;
    
    
private:
    
   list<string> elements;
    
};

stack::stack(){
   
}

void stack::push(string s){
    
    // add the elements to the stack
   elements.push_back(s);
    
}

string stack::top() const{
    
    // get the back of the list this is the top of the stack
    string frst = elements.back();
    return frst; // This will set the first value in the stack to the first string
}

void stack::pop(){
    
    // if the list is empty you cant pop anything
    if (elements.empty()) {
        
        cout << "there is nothing to pop" << endl;
        
    // if it not empty pop the top element of the stack
    } else {
        
        elements.pop_back();
        
    }
    
}

int stack::size() const{
    // get the size of the elements list and return it this is the size of the stack
   int s = elements.size();
   return s;
}

bool stack::empty() const {
    //check if the elements list is empty if so return true otherwise return false
    if (elements.empty()) {
        
        return true;
        
    } else {
        
        return false;
        
    }
    
}
#endif