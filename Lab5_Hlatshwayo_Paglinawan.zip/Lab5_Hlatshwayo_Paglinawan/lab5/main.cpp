//
//  main.cpp
//  lab5
//
//  Created by Mbusi Hlatshwayo on 5/27/15.
//  Copyright (c) 2015 Mbusi Hlatshwayo. All rights reserved.
//

#include <iostream>

int main(int argc, const char * argv[]) {
    // insert code here...
    std::cout << "Hello, World!\n";
    return 0;
}
